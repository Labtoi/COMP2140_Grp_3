import { Analysis, NewAnalysis } from '../models/Analysis'

export interface IAnalysisRepo {
    GetAnalysis(id: string): Promise< Analysis| null>;
    GetAllAnalysis(): Promise<Analysis[]>;
    GetAllIDs(): Promise<string[]>

    GetAllRevenue(dateRange: { start: string; end: string }): Promise<number>;
    LeastPopularMeal(dateRange: { start: string; end: string }): Promise<string | null>;
    MostPopularMeal(dateRange: { start: string; end: string }): Promise<string | null>;
    TotalMealsSold(dateRange: { start: string; end: string }): Promise<number>;
    LeastPopularSide(dateRange: { start: string; end: string }): Promise<string | null>;
    MostPopularSide(dateRange: { start: string; end: string }): Promise<string | null>;
    TotalSidesSold(dateRange: { start: string; end: string }): Promise<number>;
    
    RemoveAnalysis(id: string): Promise<void>;
    AddAnalysis(analysis: NewAnalysis): Promise<Analysis>;
}