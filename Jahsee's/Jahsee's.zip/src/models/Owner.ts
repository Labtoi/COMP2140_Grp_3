import { User } from './User';
import { owner } from '../owner';


export class Owner extends User {
  constructor (id: string, name: string, password?: string) {
    super(id, name, password);

  }
}